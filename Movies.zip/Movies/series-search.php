<?php
include "header.php";

?>


<title>Series search</title>
	
	
<script src="http://0.0.0.0:8080/js/lm-script.js"></script>



<?php include "head.php"; ?>


<div id="search-res-container">

	<br>
	<br>
	<br>
	<small id="small-res">Series</small>
	
	

	
	
	<div id="search-result">



	</div>
	
</div>


	
<?php include "footer.php"; ?>

