<?php
//$fileUrl = "https://ella.netnaijafiles.xyz/621ddcb33f3b9951/Rebel_Moon_-_Part_Two_The_Scargiver_(2024)_(NetNaija.xyz).mkv?download_token=06006e6d9fb55456c29a3fac67ab6ee8d297bee6af895eead09e5659ca68e01d";

header('Content-Type: image/mpeg');
header('Content-Disposition: attachment; filename="img.jpg"' );

//readfile($fileUrl);