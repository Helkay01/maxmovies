<?php
include "header.php";

?>


<title>About IMD</title>
	
	

<?php include "head.php"; ?>


<div id="search-res-container">

	<br>
	<br>
	<br>
	<small id="small-res">About IMD</small>
	
	
	<div style=" font-style: italic; margin: 5px;">
		<p>
			<b>Internet Movies Downloader (IMD)</b> is a movie downloader site, not movies streaming website or app. It searches for old or new movies from the popular movies streaming apps and websites and displays the download links of the movies.
		</p>

	</div>
	
	
	<br>
	<br>

	
	
	<div style="font-style: italic; margin: 5px;">
		<span style="padding-bottom: 5px; border-bottom: 5px solid red; "><b>Disclaimer</b></span>
		
		<br>
		<br>
		
		<p>
			IMD does not claim the ownership of the movies on this site. IMD is only a movie downloader, movies are not uploaded on this site, only movies details and download links are available.
		</p>
	
	</div>
	
</div>


	
<?php include "footer.php"; ?>

