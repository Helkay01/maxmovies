<?php
echo $_SERVER['HTTP_COOKIE'];

echo '<br>';

echo $_SERVER['HTTP_USER_AGENT'];

echo '<pre>';
print_r($_SERVER);
echo '</pre>';


?>

<script>
alert(document.location);

</script>