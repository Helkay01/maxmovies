<?php
include "file:///storage/emulated/0/Movies/connection.php";

$_SESSION['mp'] = $_POST['da'];


echo $_SESSION['mp'];
