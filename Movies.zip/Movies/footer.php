

	<div id="loader"></div>



</div>







<div id="imdb-series">
	<span style="color: red; float: right; margin: 15px;" onclick="
		var h = $('div#imdb-series').slideToggle();

	"><b>X</b></span>
	
	<br>


	<center style="padding: 8px; margin-top: 10px">
		<span><small>
			<i>
				<b>Check the new releases tv series on the Internet Movies Database (IMDB) and download here.</b>
			</i></small>
		</span>
	</center>
	
	
	
	<div id="imdb-loader"></div>
	
	<br>
	
	<div class="imdb-result" id="imdb-series-result" style="height: 360px; margin-top: 20px; border-top: 1px solid darkgrey; overflow: scroll;">
	
	</div>
	
	
</div>




<div id="imdb-kd">
	<span style="color: red; float: right; margin: 15px;" onclick="
		var h = $('div#imdb-kd').slideToggle();

	"><b>X</b></span>
	
	<br>


	<center style="padding: 8px; margin-top: 10px">
		<span><small>
			<i>
				<b>Check the new releases korean drama on the Internet Movies Database (IMDB) and download here.</b>
			</i></small>
		</span>
	</center>
	
	
	
	<div id="imdb-loader"></div>
	
	<br>
	
	<div class="imdb-result" id="imdb-kd-result" style="height: 360px; margin-top: 20px; border-top: 1px solid darkgrey; overflow: scroll;">
	
	</div>
	
	
</div>




<div id="imdb-bollywood">
	<span style="color: red; float: right; margin: 15px;" onclick="
		var h = $('div#imdb-bollywood').slideToggle();

	"><b>X</b></span>
	
	<br>


	<center style="padding: 8px; margin-top: 10px">
		<span><small>
			<i>
				<b>Fetching new bollywood movies from the Internet Movies Database (IMDB)</b>
			</i></small>
		</span>
	</center>
	
	
	
	<div id="imdb-loader"></div>
	
	<br>
	
	<div class="imdb-result" id="imdb-bollwood-result" style="height: 360px; margin-top: 0px; border-top: 1px solid darkgrey; overflow: scroll;">
	
	</div>
	
	
</div>




<div id="imdb-old-movies">
	<span style="color: red; float: right; margin: 15px;" onclick="
		var h = $('div#imdb-old-movies').slideToggle();

	"><b>X</b></span>
	
	<br>


	<center style="padding: 8px; margin-top: 10px">
		<span><small>
			<i>
				<b>Check the old movies on the Internet Movies Database (IMDB) and download here.</b>
			</i></small>
		</span>
	</center>
	
	
	
	<div id="imdb-loader"></div>
	
	<br>
	
	<div class="imdb-result" id="imdb-old-movies-result" style="height: 360px; margin-top: 0px; border-top: 1px solid darkgrey; overflow: scroll;">
		<a href="">bbbb</a>
	</div>
	
	
</div>


<footer>


</footer>

</body>
</html>